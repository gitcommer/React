import React from 'react';
import { Header } from './components/Header';
import { Balance } from './components/Balance';
import { IncomeExpenses } from './components/IncomeExpenses';
import { TransactionList } from './components/TransactionList';
import { AddTransaction } from './components/AddTransaction';       //6.using-hooks

import { GlobalProvider } from './context/GlobalState';             //7.context - 

import './App.css';

function App() {
  return (
    <GlobalProvider>                  {/*8.context - */}
      <Header />
      <div className="container">
        <Balance />
        <IncomeExpenses />
        <TransactionList />           {/*7.using-hooks*/}
        <AddTransaction />
      </div>
    </GlobalProvider>
  );
}

export default App;
