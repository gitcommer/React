import React, {useState, useContext} from 'react'           //1.using-hooks - useState
import { GlobalContext } from '../context/GlobalState';

export const AddTransaction = () => {
  const [text, setText] = useState('');                     //2.using-hooks - this will get the data of the input 'string'
  const [amount, setAmount] = useState(0);                  //3.using-hooks - this will get the data of the input 'number'

  const { addTransaction } = useContext(GlobalContext);

  const onSubmit = e => {
    e.preventDefault();

    const newTransaction = {
      id: Math.floor(Math.random() * 100000000),
      text,
      amount: +amount
    }

    addTransaction(newTransaction);
  }

  return (
    <>
      <h3>Add new transaction</h3>
      <form onSubmit={onSubmit}>
        <div className="form-control">
          <label htmlFor="text">Text</label>
          <input type="text" value={text} onChange={(e) => setText(e.target.value)} placeholder="Enter text..." />    {/*4.using-hooks*/}
        </div>
        <div className="form-control">
          <label htmlFor="amount"
            >Amount <br />
            (negative - expense, positive - income)</label
          >
          <input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="Enter amount..." />    {/*5.using-hooks, go to App.js*/}
        </div>
        <button className="btn">Add transaction</button>
      </form>
    </>
  )
}
