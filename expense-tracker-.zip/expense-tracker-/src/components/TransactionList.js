import React, { useContext } from 'react';                //1.display state to ui - useContext to use state
import { Transaction } from './Transaction';              //2.display state to ui - get state data in Transaction.js
import { GlobalContext } from '../context/GlobalState';   //3.display state to ui - get state data

export const TransactionList = () => {

  // const context = useContext(GlobalContext);           //display state data to console
  // console.log(context);

  const { transactions } = useContext(GlobalContext);     //4.display state to ui - use context and assign to transaction
  return (
    <>
      <h3>History</h3>
      <ul className="list">
        {transactions.map(transaction => (<Transaction key={transaction.id} transaction={transaction} />))}   {/*5.display state to ui - Transaction.js data*/}
      </ul>                                                                                                   {/*6.display state to ui - transaction={transaction} is a props*/}
    </>                                                                                                       {/*  display state to ui - => is a foreach*/}
  )
}
