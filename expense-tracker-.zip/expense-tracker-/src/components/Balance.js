import React, { useContext } from 'react';                                    //1.Balance - hooks
import { GlobalContext } from '../context/GlobalState';                       //2.Balance - state 

export const Balance = () => {
  const { transactions } = useContext(GlobalContext);                         //3.Balance - use context 
  const amounts = transactions.map(transaction => transaction.amount);        //4.Balance - get all the amount in the array
  const total = amounts.reduce((acc, item) => (acc += item), 0).toFixed(2);   //5.Balance - reduce() to add all amount, tofixed() two decimal places
  return (
    <>
      <h4>Your Balance</h4>
    <h1>${total}</h1>                                                         {/*6.Balance - display total*/}
    </>
  )
}
