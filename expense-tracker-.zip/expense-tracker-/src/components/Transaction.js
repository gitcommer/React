import React, {useContext} from 'react';                      //1.delete - 
import { GlobalContext } from '../context/GlobalState';       //1.delete - 

export const Transaction = ({ transaction }) => {             //7.display state to ui - 
  const { deleteTransaction } = useContext(GlobalContext);    //1.delete - 

  const sign = transaction.amount < 0 ? '-' : '+';  //this is for negative or positive amount

  return (
    <li className={transaction.amount < 0 ? 'minus' : 'plus'}>  {/*1.red green amount - this is for css color of positive(green), negative(red)*/}
      {transaction.text}    {/*8.display state to ui - */}
      <span>{sign}${Math.abs(transaction.amount)}</span>  {/*2.red green amount - Math.abs() - absolute number or always be positive, wla nay decimal*/}
      <button onClick={() => deleteTransaction(transaction.id)} className="delete-btn">x</button>     {/*1.delete - */}
    </li>
  )
}
