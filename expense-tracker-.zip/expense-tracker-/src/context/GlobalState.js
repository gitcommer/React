import React, { createContext, useReducer } from 'react';               //1.context - createContext
import AppReducer from './AppReducer';

// Initial state
const initialState = {                                                  //2.context - state
  transactions: []
}

// Create context
export const GlobalContext = createContext(initialState);               //3.context - export state data

// Provider component
export const GlobalProvider = ({ children }) => {                       //4.context - children will have access to state(initialState), dispatch(AppReducer)
  const [state, dispatch] = useReducer(AppReducer, initialState);

  // Actions
  function deleteTransaction(id) {
    dispatch({
      type: 'DELETE_TRANSACTION',
      payload: id                                                         //1.delete - payload: - is in AppReducer.js
    });
  }

  function addTransaction(transaction) {                                  //1.addTransaction - (transaction) this will get the total transaction
    dispatch({
      type: 'ADD_TRANSACTION',
      payload: transaction
    });
  }

  return (<GlobalContext.Provider value={{                              //5.context - send data to children, go to AppReducer.js
    transactions: state.transactions,                                   //  state data
    deleteTransaction,                                                  //2.delete - pass to the provider
    addTransaction                                                      //2.addTransaction - pass to the provider
  }}>
    {children}
  </GlobalContext.Provider>);
}