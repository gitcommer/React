export default (state, action) => {      //6.context - get the state and action request, go to App.js
  switch(action.type) {                  //3.delete - action.type is DELETE_TRANSACTION
    case 'DELETE_TRANSACTION':
      return {
        ...state,
        transactions: state.transactions.filter(transaction => transaction.id !== action.payload)
      }
    case 'ADD_TRANSACTION':             //3.add - action.type is DELETE_TRANSACTION
      return {
        ...state,
        transactions: [action.payload, ...state.transactions]
      }
    default:
      return state;
  }
}