import React, { Component } from "react";
import "./ClearButton.css";

class ClearButton extends Component {
  render() {
    return( 
      <div 
        className="clear-btn"
        onClick={() => this.props.handleClear()}      //3.clear-button - here is clearing the state, not the input field
      >
        {this.props.children}
      </div>
    )
  }
}

export default ClearButton;
