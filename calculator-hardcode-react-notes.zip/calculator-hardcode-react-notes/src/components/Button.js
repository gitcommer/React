import React, { Component } from "react";
import "./Button.css";

class Button extends Component {
  isOperator = val => {                                                                         //val - will get the value of the button when click
    return !isNaN(val) || val === "." || val === "=";                                           //isNaN() - is a react fuction that check if the value is 'not' a number or . or =
  };

  render() {
    return( 
      <div 
        className={`button ${this.isOperator(this.props.children) ? "" : "operator"}`}        //button is a class in css, if not click number of empty(""), else return the operator(number)
        onClick={() => this.props.handleClick(this.props.children)}
      >
        {this.props.children}                                                               
      </div>
    )
  }
}

export default Button;
