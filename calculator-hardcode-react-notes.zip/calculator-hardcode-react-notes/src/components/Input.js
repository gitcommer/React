import React, { Component } from "react";
import "./Input.css";

class Input extends Component {
  render() {
    return( 
      <div className="input">                 {/*meaning apply css here input </Button> in App.js*/}
        {this.props.children}                 
      </div>
    )
  }
}

export default Input;
