import React, { Component } from "react";
import "./App.css";
import Button from "./components/Button";
import Input from "./components/Input";
import ClearButton from "./components/ClearButton";

class App extends Component {
  constructor(props) {                                          //constructor - automatically called during the creation of an object in a class
    super(props);                                               //mo access siya og variable sa parent class

    this.state = {
      input: "",
      previousNumber: "",
      currentNumber: "",
      operator: ""
    };
  }

  addToInput = val => {                                         // 2.add - imput only numbers here
    this.setState({ input: this.state.input + val });           //      - concatenate the inputted numbers, this.state.input - is simply the form input                                      
  };

  addDecimal = val => {                                         // 2.decimal - only add decimal if there is no current decimal point present in the input area
    if (this.state.input.indexOf(".") === -1) {                 //           - you can only add 1 decimal, -1 meaning adto siya ma butang sa right side
      this.setState({ input: this.state.input + val });
    }
  };

  addZeroToInput = val => {                                     // if this.state.input is not empty then add zero
    if (this.state.input !== "") {
      this.setState({ input: this.state.input + val });
    }
  };

  clearInput = () => {                                                                             
    this.setState({ input: "" });                             //2.clear-button - clear the display field                         
  };

  add = () => {                                               // 3.add - 
    this.state.previousNumber = this.state.input;             //       - kohaa ang una na gi input unya i store sa previousNumber
    this.setState({ input: "" });                             //       - if mo input kag +, -, etc. kay i clear ang  field 
    this.state.operator = "plus";
  };

  subtract = () => {
    this.state.previousNumber = this.state.input;
    this.setState({ input: "" });
    this.state.operator = "subtract";
  };
  
  multiply = () => {
    this.state.previousNumber = this.state.input;
    this.setState({ input: "" });
    this.state.operator = "multiply";
  };

  divide = () => {
    this.state.previousNumber = this.state.input;
    this.setState({ input: "" });
    this.state.operator = "divide";
  };

  evaluate = () => {                                        // 4.add - evaluate is equal                                      
    this.state.currentNumber = this.state.input;

    if (this.state.operator == "plus") {
      this.setState({
        input:
          parseInt(this.state.previousNumber) +             // 5.add - add the numbers like previousNumber + currentNumber
          parseInt(this.state.currentNumber)
      });
    } else if (this.state.operator == "subtract") {
      this.setState({
        input:
          parseInt(this.state.previousNumber) -
          parseInt(this.state.currentNumber)
      });
    } else if (this.state.operator == "multiply") {
      this.setState({
        input:
          parseInt(this.state.previousNumber) *
          parseInt(this.state.currentNumber)
      });
    } else if (this.state.operator == "divide") {
      this.setState({
        input:
          parseInt(this.state.previousNumber) /
          parseInt(this.state.currentNumber)
      });
    }
  };

  render() {
    return (
      <div className="App">
        <div className="calc-wrapper">
          <div className="row">
            <Input>{this.state.input}</Input>                                     {/*display data*/}                             
          </div>
          <div className="row">
            <Button handleClick={this.addToInput}>7</Button>                      {/*1.add - */}              
            <Button handleClick={this.addToInput}>8</Button>
            <Button handleClick={this.addToInput}>9</Button>
            <Button handleClick={this.divide}>/</Button>
          </div>
          <div className="row">
            <Button handleClick={this.addToInput}>4</Button>
            <Button handleClick={this.addToInput}>5</Button>
            <Button handleClick={this.addToInput}>6</Button>
            <Button handleClick={this.multiply}>*</Button>
          </div>
          <div className="row">
            <Button handleClick={this.addToInput}>1</Button>
            <Button handleClick={this.addToInput}>2</Button>
            <Button handleClick={this.addToInput}>3</Button>
            <Button handleClick={this.add}>+</Button>
          </div>
          <div className="row">
            <Button handleClick={this.addDecimal}>.</Button>                    {/*1.decimal - */}    
            <Button handleClick={this.addZeroToInput}>0</Button>
            <Button handleClick={this.evaluate}>=</Button>
            <Button handleClick={this.subtract}>-</Button>
          </div>
          <div className="row">
            <ClearButton handleClear={this.clearInput}>Clear</ClearButton>      {/*1.clear-button - handleClear is in ClearButton.js*/}     
          </div>
        </div>
      </div>
    );
  }
}

export default App;
